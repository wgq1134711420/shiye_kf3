# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
# from fsp_spider.items import ShiyeItem
import os
import sys
import htmlparser
from urllib.parse import urljoin
import json
from scrapy.utils.request import request_fingerprint
import redis
import re
import time
import datetime
from spider_util.utils.util import add_uuid
from scrapy.conf import settings


class MySpider1(RedisSpider):
    name = 'dangdang1'
    allowed_domains = ['dangdang.com']
    # ori_path = settings.get('ORI_PATH')
    # dir_name = 'cbrc/yjhjg'
    encoding = "gbk"

    start_urls = ['http://category.dangdang.com/cid4004279-a1%3A17667.html']
    headers = {
        # "Referer": "http://www.sse.com.cn/disclosure/credibility/supervision/measures/",
        "Referer": "http://category.dangdang.com/cid4001075-a1%3A2276.html",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36",
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse, headers=self.headers, dont_filter=True)

    def parse(self, response):
        try:
            data = htmlparser.Parser(response.body.decode(self.encoding))

        except Exception as e:
            print('response failed %s'%e)
            return
        start_url = response.url

        li_list = data.xpathall('''//ul[@class="bigimg cloth_shoplist"]/li''')
        for li in li_list:
            title = li.xpath('''//p[@class="name"]//a''').text().strip()
            price = li.xpath('''//p[@class="price"]''').text().strip()
            item = {"title": title, "price": price}
            print(item)

        # td_list = data.xpathall('//div[@class="title"]/a')
        # for td in td_list:
        #     href = td.xpath('//@href').text()
        #     if href:
        #         href = urljoin(start_url, href)
        #         print(1111, href)
                # yield scrapy.Request(href, callback=self.second_parse, dont_filter=True)
