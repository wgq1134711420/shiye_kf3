# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
# from fsp_spider.items import ShiyeItem
import os
import sys
import htmlparser
from urllib.parse import urljoin
import json
from scrapy.utils.request import request_fingerprint
import redis
import re
import time
import datetime
from spider_util.utils.util import add_uuid
from scrapy.conf import settings


class MySpider(RedisSpider):
    name = 'fsp_news_sasac'
    allowed_domains = ['sasac.gov.cn']
    # ori_path = settings.get('ORI_PATH')
    # dir_name = 'cbrc/yjhjg'
    encoding = "utf8"

    start_urls = ['http://www.sasac.gov.cn/n2588030/n2588929/index.html']
    headers = {
        # "Referer": "http://www.sse.com.cn/disclosure/credibility/supervision/measures/",
        "Referer": "http://www.sasac.gov.cn/n2588030/n2588924/index.html",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.77 Safari/537.36",
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse, headers=self.headers, dont_filter=True)

    def parse(self, response):
        try:
            data = htmlparser.Parser(response.body.decode(self.encoding))

        except Exception as e:
            print('response failed %s'%e)
            return
        start_url = response.url
        td_list = data.xpathall('//span[@id="comp_2603340"]/li/a')
        for td in td_list:
            href = td.xpath('//@href').text()
            if href:
                href = urljoin(start_url, href)
                print(1111, href)
                yield scrapy.Request(href, callback=self.second_parse, headers=self.headers)

    def second_parse(self, response):
        try:
            data = htmlparser.Parser(response.body.decode(self.encoding))

        except Exception as e:
            print('second response failed %s' % e)
            return
        item = {}
        url = response.url
        fp_id = request_fingerprint(response.request)
        title = data.xpath("//title").text().strip()
        content = data.xpath("//div[@class='zsy_comain']").text().strip()
        uid = add_uuid(url)
        gtime = int(time.time())
        ctime = gtime
        collection_name = 'fsp_news_sasac_raw'

        item["fp_id"] = fp_id
        item["title"] = title
        item["ctime"] = ctime
        item["gtime"] = gtime
        item["url"] = url
        item["content"] = content
        item["collection_name"] = collection_name
        item["uid"] = uid
        # print(self.server)
        # print(json.dumps(item, ensure_ascii=False))
        yield item

