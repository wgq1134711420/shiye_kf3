# -*- coding: utf-8 -*-
import scrapy
from scrapy_redis.spiders import RedisSpider
import os
import sys
import htmlparser
from urllib.parse import urljoin
import json
from scrapy.utils.request import request_fingerprint
import redis
import re
import time
import datetime
from spider_util.utils.util import add_uuid, local_timestamp
from spider_util.utils.download_util import dow_img_acc, parse_main
from scrapy.conf import settings


class MySpider(RedisSpider):
    name = 'fsp_mem_yantai'
    allowed_domains = ['ajj.yantai.gov.cn']
    ori_path = settings.get('ORI_PATH')
    dir_name = 'fsp/fsp_mem'
    encoding = "utf8"
    start_urls = ["http://ajj.yantai.gov.cn/col/col611/index.html"]
    headers = {
        # "Cookie": "acw_tc=784e2c8b15637620436366833e5d2051beff6fe143b50d05dca8cac03f601d; SERVERID=d2e5436f826f0ca88944db105fd8663e|1563762052|1563762043",
        'Host': 'ajj.yantai.gov.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3325.181 Safari/537.36'
    }

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, callback=self.parse, headers=self.headers, dont_filter=True)

    def parse(self, response):
        start_url = response.url
        try:
            data = htmlparser.Parser(response.body.decode(self.encoding))
        except Exception as e:
            print('response failed %s' % e)
            return
        # print(data.data)
        org_list = data.regexall('<td height="30" align="left">.*?</td>')
        for org in org_list:
            if org:
                title = org.xpath('//span[@class="content14"]/a/text()').text().strip()
                ctime = org.xpath('''//span[@class="STYLE5"]/text()''').text().strip()
                ctime = re.sub('\s+', '', ctime)
                print(ctime)
                org = org.xpath('''//span[@class="content14"]/a/@href''').text().strip()
                if title:
                    url = urljoin(start_url, org)
                    print(url)
                    ctime = local_timestamp(ctime)
                    item = {'ctime': ctime, 'title': title}
                    print(item)
                    yield scrapy.Request(url, callback=self.detail_parse, meta={'item': item}, headers=self.headers, dont_filter=True)

    def detail_parse(self, response):
        fp_id = request_fingerprint(response.request)
        item = response.meta['item']
        try:
            data = htmlparser.Parser(response.body.decode(self.encoding))
        except Exception as e:
            print('second response failed %s' % e)
            return
        url = response.url
        # title = data.xpath('''//h2''').text().strip()
        contents = []  # 全部的文本内容
        content_list = data.xpathall(
            '''//div[@id="zoom"]//p | //div[@id="zoom"]//td''')
        for con in content_list:
            con = con.text().strip()
            if con:
                contents.append(con)
        content_x = data.xpath(
            '''//div[@id="zoom"]''').data
        content_xml = content_x
        label = {}
        img_list = data.xpathall(
            '//div[@id="zoom"]//img')
        if img_list:
            for count, image in enumerate(img_list):
                image_dict = {}
                img_sele = image.data
                image_url = image.xpath('//@src').text().strip()
                if image_url:
                    image_url = urljoin(url, image_url)
                    node = '#image{}#'.format(count)
                    file_name = image_url.split('/')[-1]
                    image_dict['url'] = image_url
                    image_dict['name'] = ''
                    image_dict['file_name'] = file_name
                    dir_path = os.path.join(self.ori_path, self.dir_name)
                    if not os.path.isdir(dir_path):
                        os.makedirs(dir_path)
                    path = os.path.join(dir_path, file_name)
                    dow_img_acc(path, image_url)
                    node_p = "<p>" + node + "</p>"
                    content_x = content_x.replace(img_sele, node_p)
                    # content_x = content_x.replace(img_sele, node)
                    label[node] = image_dict

        table_list = data.xpathall(
            '//div[@id="zoom"]//table')
        if table_list:
            for count, table in enumerate(table_list):
                table_dict = {}
                node = "#table{}#".format(count)
                table_sele = table.data
                table_dict['table_xml'] = table_sele
                node_p = "<p>" + node + "</p>"
                content_x = content_x.replace(table_sele, node_p)
                label[node] = table_dict
        xml = htmlparser.Parser(content_x)
        web_contents = []  # web直接展示的content
        content_list = xml.xpathall(
            '''//p''')
        for con in content_list:
            con = con.text().strip()
            if con:
                web_contents.append(con)
        breadcrumb = []
        article_info = {}
        branch_tree = {}
        department = "中华人民共和国应急管理部"
        branch = "烟台市应急管理局"
        branch_tree["0"] = department
        branch_tree["1"] = branch
        # branch_tree["2"] = branch
        channel = ''
        accessory = []  # 附件
        all_acc = data.xpathall('''//div[@id="zoom"]//p//a''')
        if all_acc:
            for acc in all_acc:
                temp = {}
                acc_url = acc.xpath('//@href').text().strip()
                if acc_url and '@' not in acc_url:
                    acc_url = urljoin(url, acc_url)
                    name = acc.text().strip()
                    file_name = acc_url.split('/')[-1].split('=')[-1]
                    temp['url'] = acc_url
                    temp['name'] = name
                    temp['file_name'] = file_name
                    dir_path = os.path.join(self.ori_path, self.dir_name)
                    if not os.path.isdir(dir_path):
                        os.makedirs(dir_path)
                    path = os.path.join(dir_path, file_name)
                    dow_img_acc(path, acc_url)
                    file_content = parse_main(path)
                    temp['file_content'] = file_content
                    accessory.append(temp)
        webname = '中华人民共和国应急管理部'
        domain = self.allowed_domains[0]
        uid = add_uuid(url)
        gtime = int(time.time())
        # item["title"] = title
        item["collection_name"] = "fsp_department_mem_raw"
        item["branch"] = branch
        item["fp_id"] = fp_id
        item["url"] = url
        item["label"] = label
        item["contents"] = contents
        item["web_contents"] = web_contents
        item["content_xml"] = content_xml
        item["accessory"] = accessory
        item["gtime"] = gtime
        item['breadcrumb'] = breadcrumb
        item["branch_tree"] = branch_tree
        item["article_info"] = article_info
        item["spider_name"] = self.name
        item["channel"] = channel
        item["webname"] = webname
        item["domain"] = domain
        item["department"] = department
        item["uid"] = uid
        item['path'] = self.dir_name
        yield item



